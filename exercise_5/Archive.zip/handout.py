"""
Tutorial
Bokeh Server Callbacks


run with
bokeh serve --show handout.py
"""

import numpy as np
from random import sample, choices
import datetime
import pandas as pd

from bokeh.plotting import figure, show, output_file, curdoc
from bokeh.layouts import layout, column, row
from bokeh.tile_providers import get_provider, Vendors
from bokeh.models import ColumnDataSource, Slider, Range1d, LinearAxis, CheckboxButtonGroup, \
    Div, Rect, Circle, Quad, Button, AnnularWedge
from bokeh.transform import linear_cmap
from bokeh.palettes import magma, plasma
from bokeh.colors import RGB

from pyproj import transform, Proj, Transformer



"""
=============
Pandas Basics
=============
"""

"""
=======================
DataSources
=======================
ColumnDataSources can be created from a dictionary or a pandas.DataFrame

1. Create two DataSources and two plots containing the same data, 

"""

df = pd.DataFrame()
df['xs'] = None # @TODO
df['ys'] = None # @TODO

# Create a ColumnDataSource directly from a pandas dataframe
ds = None # @TODO

# Create a ColumnDataSource from a python dict
d1 = None # @TODO


"""
=======================
Callback: Changing Data
=======================

This example shows how to update the datasource within a bokeh callback. 
Here, a button click will generate new random data. 
"""

d1 = ColumnDataSource(dict(
    xs = np.arange(0, 10),
    ys = np.random.rand(10)
))

p1 = figure(plot_width=400, plot_height=400)
p1.line(x = "xs", y="ys", line_width=2, source=d1)


def callback_change_data():
    print("Button pressed")

    # @TODO Generate some new data

btn_change = Button(name="Change Data")
btn_change.on_click(callback_change_data)



"""
=========================================
Callback: Multiple Glyphs Hide/Show Glyphs
=========================================

figure().<your-glyph>() returns a renderer, if this is stored, one can later change its visibility.

"""

d2 = ColumnDataSource(dict(
    xs = np.arange(0, 10),
    ys = np.random.rand(10)
))
p2 = figure(plot_width=400, plot_height=400)
renderer = dict()

# @TODO Create two renderer, a circle and a line, store them both in the renderer dict
renderer['circles'] = None # @TODO
renderer['lines'] = None # @TODO


def callback_glyphs(new):
    print("Active Checkboxes:", new)
    # @TODO Check which buttons are currently activated and hide/show the respective renderer ()


# TODO Add a CheckboxButtonGroup for with two buttons "Circles" and "Lines" and hook them to the callback_glyphs
# TIP: Checkout the widgets page of the bokeh docs.

btn_glyphs = None # @TODO



"""
=======================
Two Axes
=======================

"""

d_axis_1 = ColumnDataSource(dict(
    xs = np.arange(0, 10),
    ys = np.random.rand(10)
))

d_axis_2 = ColumnDataSource(dict(
    xs = np.arange(0, 10),
    ys = np.random.rand(10) * 100
))

p_axis = figure(plot_width=400, plot_height=400, y_range = (0.0,1.0))
p_axis.line(x = "xs", y="ys", line_width=2, source=d_axis_1)

# @TODO add an extra_y_range to the plot with circle glyphs using the d_axis_2 datasource, and set the
# range of the axis between (0 and 100), TIP: checkout extra_y_range and Figure.add_layout in the docs


# @TODO Changing the tick color of the second range to be red



"""
===================
Callback: Selection
===================

A selection callback in bokeh usually returns the indices of the data points currently 
selected in the ColumnDataSource. 

"""

d3 = ColumnDataSource(dict(
    xs = np.arange(0, 10),
    ys = np.random.rand(10)
))

# Add a Lasso-Selection tool
p3 = figure(plot_width=400, plot_height=400, tools=['lasso_select'])
circle_renderer = p3.circle(x = "xs", y="ys", size=10, source=d3)

# @TODO Customize the glyphs for selection_glyph and nonselection_glyph for the circle_renderer


# p4 shares the ColumnDataSource with p3, the selection is therefore always in sync
p4 = figure(plot_width=400, plot_height=400)

# @TODO Create a barplot sharing the same datasource d3 as p3


# Creating a new Plot to indicate the percentage of selected items
# This needs a new datasource which we synchronize in the callback_selection with d3
d4 = ColumnDataSource(dict(xs=[0],
                           ys=[0],
                           value=[0.0],
                           text=["0%"]))
p5 = figure(plot_width=400, plot_height=400)
# @TODO add an AnnularWedge rendere to the dataset, where the current end_angle indicates the percentage
# of selected items in p3. Add a text label in the center showing the percentage as string


def callback_selection(attr, old, new):
    print("Selected Indices:", new)

    # we want to change the size of the circle in p4 based on the number
    # of selected in p3
    new_value = len(new) / len(d3.data['xs'])

    # @TODO update d4 to show the new percentage of selected values


# Hook the callback to the on_change event
d3.selected.on_change("indices", callback_selection)




"""
=================
WorldMap Examples
=================
"""


def coord2mercator(long, lat, varb = False):
    """
    Projects a decimal coordinate onto a web mercator plane.
    Can also be given as numpy.ndarray

    :param long: A single or array of decimal longitude values
    :param lat: A single or array of decimal latitude values
    :return: an array of tuples, each (Long, Lat) in web mercator
    """
    transformer = Transformer.from_crs("epsg:4326", "epsg:3857")
    return transformer.transform(lat, long)


tile_provider = get_provider(Vendors.CARTODBPOSITRON)

xmin, ymin = coord2mercator(-179.999, -80.999)
xmax, ymax = coord2mercator(179.999, 80.999)

# range bounds supplied in web mercator coordinates
world_map_left = figure(x_range=(xmin, xmax), y_range=(ymin, ymax),
                        x_axis_type="mercator", y_axis_type="mercator",
                        output_backend="webgl",
                        tools=["tap", "lasso_select", "wheel_zoom", "pan"],
                        width=800, height=800)

# Add the countries
world_map_left.add_tile(tile_provider)

world_map_left.xaxis.axis_label = "Longitude"
world_map_left.yaxis.axis_label = "Latitude"


"""
Projecting points into the web mercator coordinate system
"""

# Project the decimal coordinates into WebMercator
decimal_coords_zurich = [47.36667, 8.55]    # [Latitude, Longitude]
decimal_coords_accra =  [5.55602, -0.1969]  # [Latitude, Longitude]
decimal_coords = np.array([decimal_coords_zurich, decimal_coords_accra])

mercatorLong, mercatorLat = coord2mercator(decimal_coords[:,1], decimal_coords[:, 0])

d_world_map = ColumnDataSource(dict(
    mercatorLong=mercatorLong,
    mercatorLat = mercatorLat,
    location_name = ["Zurich", "Accra"]
))

world_map_left.circle_cross(x="mercatorLong", y ="mercatorLat", size=5, fill_color="#fc0324", source=d_world_map)
world_map_left.text(x="mercatorLong", y ="mercatorLat", text="location_name", source=d_world_map)


"""
WorldMap, with linked axes, and area

"""

# @TODO Add a second worldmap world_map_right, link the current ranges with the world_map_left,
# So that when one pans on the first, the latter will be panned/zoomed as well.


world_map_right = None # @TODO

# @TODO Try to create a grid over the whole map, with N_BINS_LAT cells in the latitude dimensions and N_BINS_LONG
# in the longitude dimension. Apply a random value between 0.0 and 0.5 to the alpha of each quad. Use the Quad Glyph.

N_BINS_LAT = 18
N_BINS_LONG = 36



lt = column([
        Div(text="""<h1> Visualization Interactions in Bokeh </h1>"""),
        # Uncomment for first Plot
        # Div(text="""<h1> Changing Data</h1>"""),
        # btn_change,
        # p1,
        #
        # Uncomment for Multiple Glyphs Hide/Show Glyphs
        # Div(text="""<h1> Show/Hide Glyphs</h1>"""),
        # btn_glyphs,
        # p2,
        #
        # Uncomment for Multiple Axis
        # Div(text="""<h1> Multiple Axis</h1>"""),
        # p_axis,
        #
        # Uncomment for Selection
        # Div(text="""<h1> Selection</h1>"""),
        # row([p3, p4, p5], sizing_mode="stretch_width"),
        #
        # Uncomment for world Plot
        # Div(text="""<h1> World Map</h1>"""),
        # row([world_map_left, world_map_right], sizing_mode="stretch_width")
    ], sizing_mode="stretch_width")

curdoc().add_root(lt)